CREATE TABLE INSURANCES (
    insurance_id INT PRIMARY KEY,
    insurance_name VARCHAR(255)
);
