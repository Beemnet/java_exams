-- create-medications.sql
CREATE TABLE MEDICATIONS (
    medication_code INT PRIMARY KEY,
    medication_name VARCHAR(255),
    medication_comment VARCHAR(255)
);
