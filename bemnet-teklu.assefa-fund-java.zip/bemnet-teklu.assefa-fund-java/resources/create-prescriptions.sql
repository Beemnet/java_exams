CREATE TABLE PRESCRIPTIONS (
    presc_id INT PRIMARY KEY,
    presc_ref_pat BIGINT,
    presc_code INT,
    presc_days INT
);
