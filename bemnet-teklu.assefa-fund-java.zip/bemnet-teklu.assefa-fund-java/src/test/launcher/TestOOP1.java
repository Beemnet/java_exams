package test.launcher;

public class TestOOP1 {
    public static void main(String[] args) {
    }

    public static void test() {

        System.out.println("bemnet-teklu.assefa@epita.fr");
    }
}
